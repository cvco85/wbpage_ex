-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 24-Ago-2017 às 18:55
-- Versão do servidor: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paddle`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `compras_eventos`
--

CREATE TABLE `compras_eventos` (
  `id` int(11) NOT NULL,
  `id_eventos` int(11) NOT NULL,
  `date_created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `compras_eventos`
--

INSERT INTO `compras_eventos` (`id`, `id_eventos`, `date_created`) VALUES
(1, 2, '2017-08-24'),
(2, 2, '2017-08-24'),
(3, 3, '2017-08-24'),
(4, 2, '2017-08-24');

-- --------------------------------------------------------

--
-- Estrutura da tabela `eventos`
--

CREATE TABLE `eventos` (
  `id` int(10) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `localizacao` varchar(100) NOT NULL,
  `participantes` int(10) NOT NULL,
  `cartaz` varchar(200) NOT NULL,
  `descricao` text NOT NULL,
  `preco` double NOT NULL,
  `date_created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `eventos`
--

INSERT INTO `eventos` (`id`, `nome`, `localizacao`, `participantes`, `cartaz`, `descricao`, `preco`, `date_created`) VALUES
(1, 'Choose your tour', 'Costa Vicentina', 20, 'event2.jpg', '', 35, '2017-07-13'),
(2, 'Surfski trips', 'Costa vicentina', 20, 'event3.jpg', '', 30, '2017-07-13'),
(3, 'West & South Coast', 'Algarve e Costa vicentina', 20, 'events.jpg', '', 40, '2017-07-13');

-- --------------------------------------------------------

--
-- Estrutura da tabela `galery`
--

CREATE TABLE `galery` (
  `id_galery` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` varchar(250) NOT NULL,
  `image` varchar(200) NOT NULL,
  `date_created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `galery`
--

INSERT INTO `galery` (`id_galery`, `title`, `description`, `image`, `date_created`) VALUES
(1, 'Canoagem Rio', 'so much fun!', 'mfts01.jpg', '2017-07-27'),
(2, 'Canoagem Mar', 'so much fun!', 'mfts02.jpg', '2017-07-27'),
(3, 'Canoagem Mar', 'so much fun!', 'mfts03.jpg', '2017-07-27'),
(4, 'Paddle & Canoagem', 'so much fun!', 'mfts04.jpg', '2017-07-27'),
(5, 'Paddle', 'so much fun!', 'mfts05.jpg', '2017-07-27'),
(6, 'Canoagem Rio', 'so much fun!', 'mfts06.jpg', '2017-07-27'),
(7, 'Canoagem Rio', 'so much fun!', 'mfts07.jpg', '2017-07-27'),
(8, 'Canoagem Rio', 'so much fun!', 'mfts08.jpg', '2017-07-27'),
(9, 'Canoagem Rio', 'so much fun!', 'mfts09.jpg', '2017-07-27'),
(10, 'Canoagem Mar', 'so much fun!', 'mfts10.jpg', '2017-07-27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `compras_eventos`
--
ALTER TABLE `compras_eventos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `galery`
--
ALTER TABLE `galery`
  ADD PRIMARY KEY (`id_galery`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `compras_eventos`
--
ALTER TABLE `compras_eventos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `eventos`
--
ALTER TABLE `eventos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `galery`
--
ALTER TABLE `galery`
  MODIFY `id_galery` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
