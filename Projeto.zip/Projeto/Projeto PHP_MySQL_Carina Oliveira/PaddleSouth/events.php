<?php 
if (isset($_POST["submit_event"])) {
  $nome=$_POST["nome"];
  $localizacao=$_POST["localizacao"];
  $preco=$_POST["preco"];
  $descricao=$_POST["descricao"];
  $email=$_POST["email"];
  $assunto="Comprar evento";
  $mensagem="Parabéns você adquiriu um evento, é diversão garantida!!!";

  $headers =  'MIME-Version: 1.0' . "\r\n"; 
  $headers .= 'From: Van <c.van.olive@gmail.com>' . "\r\n";
  $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 

  mail($email, $assunto, $mensagem, $headers);

  $_POST["submit_event"]="";
}

$raiz = "";
require $raiz."header.php"; 
//conectar com banco de dados
require $raiz."config.php";
$select = "SELECT id, nome, cartaz, descricao, localizacao, preco, participantes FROM eventos WHERE 1";
$result = mysqli_query($connection, $select);
if (mysqli_num_rows($result)>0) {?>
<div class="eventos"> 
  <?php 
  while ($row = mysqli_fetch_assoc($result)){ 
    $disponibilidade="SELECT COUNT(ce.id_eventos) as total_comprados, 
    e.participantes FROM compras_eventos ce,eventos e 
    WHERE ce.id_eventos= ".$row['id']." and e.id= ".$row['id'].";";
    $result2 = mysqli_query($connection, $disponibilidade);
    if (mysqli_num_rows($result2)==1) {
      $row2 = mysqli_fetch_assoc($result2);
      if($row2['total_comprados']<=$row2['participantes']){
        echo "disponível";
      }else{
        echo "esgotado";
      }}
      ?>
      <article class="evt">
      <form action="" method="POST">
      <input type="hidden" value="<?php echo $row['nome'];?>" name="nome">
      <input type="hidden" value="<?php echo $row['localizacao'];?>" name="localizacao">
      <input type="hidden" value="<?php echo $row['preco'];?>" name="preco">
      <input type="hidden" value="<?php echo $row['descricao'];?>" name="descricao">
      <!--   <a href="event.php?id=<?php //echo $row['id'];?>"> -->
         <img class="imagemevento" src="img/<?php echo $row['cartaz']; ?>" alt="" > 
         <span>Nome:<?php echo $row['nome'];?></span><br>
         <span>Preço:<?php echo $row['preco'];?></span><br>
         <span>Quantidade:<?php echo $row['participantes'];?></span><br>
         <span>Local:<?php echo $row['localizacao'];?></span><br>
         <span>Descrição:<?php echo $row['descricao'];?></span><br>
         <input type="email" name="email" placeholder="Escreva seu email" required>
         <input type="submit" name="submit_event" value="Comprar">
       <!-- </a> -->
       </form>
     </article>
  <?php } ?>
</div>	
  <?php 
 } else {
 echo "Não existem eventos cadastrados, por favor entrar em contacto com o suporte.";
 }
 require $raiz."footer.php";
 ?>

