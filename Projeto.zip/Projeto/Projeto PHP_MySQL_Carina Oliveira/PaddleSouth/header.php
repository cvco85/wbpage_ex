<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  	<link rel="stylesheet" type="text/css" href="<?php echo $raiz;?>css/style.css">
	<title>Paddle South Portugal</title>
	
</head>
<body>

    <header>
	<div class="h1"> 
			<div class="logo"><img src="<?php echo $raiz;?>img/paddlesouth.jpg.jpg" width="125px"></div>
			<h1>Paddle South Portugal</h1>
			<h2> Canoagem | Paddle | Desportos Aquáticos Rio e Mar </h2>
			<hr/>
	<nav>
      <ul>
          <button name="home"><a href="<?php echo $raiz;?>index.php">Homepage</a></button>
          <button name="eventos"><a href="<?php echo $raiz;?>events.php">Eventos</a></button>
          <button name="galeria"><a href="<?php echo $raiz;?>galery.php">Galeria Fotos</a></button>
          <button name="contact"><a href="<?php echo $raiz;?>contacts.php">Contatos</a></button>
          <button name="form"><a href="<?php echo $raiz;?>form.php">Inscrição</a></button>
      </ul>
    </nav>
    <hr/>
    </header>