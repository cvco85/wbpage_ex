<?php 
$raiz = "";
require $raiz."header.php";
?>

	<section>
			<!-- <form action="formularios2.html" method="get" autocomplete=""> -->
	<h2>Formulário de Inscrição</h2>
		<form method="post" enctype="multipart/form-data">
			<table class="table table-bordered">
	<Tr>
		<Td colspan="2"></Td>
	</Tr>
				
				<tr>
					<td>Nome </td>
					<Td><input  type="text"  class="form-control" name="n" required/></td>
				</tr>
				<tr>
					<td>Email </td>
					<Td><input type="email"  class="form-control" name="e" required/></td>
				</tr>
				
				<tr>
					<td>Password </td>
					<Td><input type="password"  class="form-control" name="p" required/></td>
				</tr>
				
				<tr>
					<td>Contacto </td>
					<Td><input  class="form-control" type="number" name="mob" required/></td>
				</tr>
				
				<tr>
					<td>Género </td>
					<Td>
				Masculino <input type="radio" name="gen" value="m" required/>
				Feminino <input type="radio" name="gen" value="f"/>
				Outro <input type="radio" name="gen" value="o"/>	
					</td>
				</tr>
				
				<tr>
					<td>Escolhe o evento</td>
					<Td>
					Paddle <input value="Paddle" type="checkbox" name="hob[]"/>
					Kayak Sea <input value="Kayak Sea" type="checkbox" name="hob[]"/>
					Kayak River <input value="Kayak River" type="checkbox" name="hob[]"/>
					</td>
				</tr>
				
				<tr>
					<td>Data de Nascimento</td>
					<Td>
					<select name="yy" required>
					<option value="">Ano</option>
					<option>1950</option><option>1951</option><option>1952</option><option>1953</option><option>1954</option><option>1955</option><option>1956</option><option>1957</option><option>1958</option><option>1959</option><option>1960</option><option>1961</option><option>1962</option><option>1963</option><option>1964</option><option>1965</option><option>1966</option><option>1967</option><option>1968</option><option>1969</option><option>1970</option><option>1971</option><option>1972</option><option>1973</option><option>1974</option><option>1975</option><option>1976</option><option>1977</option><option>1978</option><option>1979</option><option>1980</option><option>1981</option><option>1982</option><option>1983</option><option>1984</option><option>1985</option><option>1986</option><option>1987</option><option>1988</option><option>1989</option><option>1990</option><option>1991</option><option>1992</option><option>1993</option><option>1994</option><option>1995</option><option>1996</option><option>1997</option><option>1998</option><option>1999</option><option>2000</option><option>2001</option><option>2002</option><option>2003</option><option>2004</option><option>2005</option><option>2006</option><option>2007</option><option>2008</option><option>2009</option><option>2010</option><option>2011</option><option>2012</option><option>2013</option><option>2014</option><option>2015</option><option>2016</option>					
					</select>
					
					<select name="mm" required>
					<option value="">Mês</option>
					<option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option>					
					</select>
					
 					
					<select name="dd" required>
					<option value="">Dia</option>
					<option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option><option>8</option><option>9</option><option>10</option><option>11</option><option>12</option><option>13</option><option>14</option><option>15</option><option>16</option><option>17</option><option>18</option><option>19</option><option>20</option><option>21</option><option>22</option><option>23</option><option>24</option><option>25</option><option>26</option><option>27</option><option>28</option><option>29</option><option>30</option><option>31</option>					
					</select>
					
					</td>
				</tr>
				
				<tr>
					
				<Td colspan="2" align="center">
				<input type="submit" class="btn btn-success" value="Salvar" name="salvar"/>
				<input type="reset" class="btn btn-success" value="Apagar" name="apagar"/>
				</td>

				</tr>
			</table>
		</form>

		
		</form>
	</section>
			
<?php 
require $raiz."footer.php";
?>

</body>
</html>