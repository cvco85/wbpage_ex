<?php 
$raiz = "";
require $raiz."header.php";
?>

		<div class="videopost">
    		<video width="700" height="540" controls poster="img/videopost.png" onclick="this.play()">
      		<source src="video/introvideo.mp4" type="video/mp4" img>
      		</video>
    	</div>
			<br>

		<div class="text"> 
			<h3><strong>Paddle South Portugal</strong> é um centro de atividades relacionadas com canoagem e SUP. 
			Estamos localizados em Vila Nova de Milfontes, mas a nossa área de atuação estende-se por toda a costa alentejana e algarvia, com o objetivo de explorar os melhores locais de toda a costa, rios e lagos. 
			Realizamos atividades variadas, tais como, Surfski Trips, Kayak Tours e SUP Tours, em diversos locais.
			Na vertente do Surfski, procuramos proporcionar percursos com as melhores condições de downwind e baseamo-nos no método de ensino de Oscar Chalupsky.
			Temos como parceiros NELO kayaks, Braca Paddles e Grupo Duna Parque Hotel. 
			Se queres reservar uma temporada radical, com muito desporto à mistura e contacto com a natureza, a <strong>Paddle South Portugal</strong> é a escolha certa!
			De que estás à espera para embarcar nesta aventura connosco?</h3>
            <br>
		<div class="sponcers"> 
			     <img src="img/dp_hotel.png" width="300px">
			     <img src="img/bracalogo.png.png" width="300px">
			     <br>
			     <br>
				 <img src="img/logonelo.png.png" width="400px">
		</div>
	
<?php 
require $raiz."footer.php";
?>
  </header>	
 </body>
</html>	