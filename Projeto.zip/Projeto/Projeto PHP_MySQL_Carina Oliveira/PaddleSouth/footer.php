<hr/>            
		<br>
			<a href="https://www.facebook.com/paddlesouthportugal/"><img src="<?php echo $raiz;?>img/facebook.png" width="5%"></a>
			<a href="https://www.instagram.com/paddlesouthportugal/"><img src="<?php echo $raiz;?>img/instagram.png" width="4.5%"></a>
		<br>
		<br>

	<footer>
			<h5>Todos os direitos reservados Paddle South Portugal 2017®</h5>
	</footer>
		<br>
</body>
</html>