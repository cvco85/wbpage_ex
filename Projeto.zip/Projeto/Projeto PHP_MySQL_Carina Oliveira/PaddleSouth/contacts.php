 <?php 
$raiz = "";
require $raiz."header.php";
?>

		<!-- Maps -->
	<div class="mapa">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d100924.58447240981!2d-8.819837490641389!3d37.76910082319989!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd1ba17a9ef55c9d%3A0xba417b8a674a37c0!2sVila+Nova+de+Milfontes%2C+Portugal!5e0!3m2!1spt-PT!2spt!4v1496453493131" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>		
		<hr/>

	<div> 
		<h2><strong>Contatos:<strong></h2>
		<h3>Avenida Marginal, 7645 Vila Nova de Milfontes</h3>
		<h3>963 659 417</h3>
		<h3>paddlesouthportugal@gmail.com</h3>
	</div>          

<?php 
require $raiz."footer.php";
?>

</body>
</html>