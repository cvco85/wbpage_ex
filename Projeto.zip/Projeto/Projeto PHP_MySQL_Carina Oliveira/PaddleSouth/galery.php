<?php 
$raiz = "";
require $raiz."header.php";
require $raiz."config.php";
?>

    <div class="container">
    <h2>Galeria de Imagens</h2>
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
    <!-- Indicators -->

    <?php
    
    $query="select * from galery where 1;";
    $result = mysqli_query($connection, $query);
    $i=0;
    while ($row = mysqli_fetch_assoc($result)) {
    ?>
      
      <li data-target="#myCarousel" data-slide-to="<?php echo $i; ?>" <?php 
      if($i==0){
        echo "class = 'active'";
      }
      //echo $i==1 ? active : "";
   ?>></li>

      <?php
      $i = $i +1;
      //$i++;
      }
      ?>
    </ol>

    <!-- Wrapper for slides -->
<div class="carousel-inner">

<?php
$query="select * from galery where 1;";
$i=1;
    $result = mysqli_query($connection, $query);
    while ($row = mysqli_fetch_assoc($result)) {
      // print_r($row);
      // die();
?>

  <div class="item <?php 
      if($i==1){
        echo 'active';
      }
      //echo $i==1 ? active : "";
   ?>">
        <img src="img/<?php echo $row["image"];?>" alt="" style="width:100%;">
        <div class="carousel-caption">
          <h3><?php echo $row["title"];?></h3>
          <p>so much fun!</p>
        </div>
      </div>
<?php
$i = $i +1;
//$i++;
}
?>
  
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Anterior</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Próximo</span>
    </a>
  </div>
</div>          
<?php 
require $raiz."footer.php";
?>

</body>
</html>